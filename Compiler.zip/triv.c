/* trivial test program to see what C compiles */
/* cc driver.c triv.c       */

void graph1()
  { int i;
    i = 3;
  }
