/* use lexandr.c instead.  See the makefile .    */
